"google docs>android studio, dont tell josh" - arrowhead 2021


if (google docs > android studio) {
    System.out.println("wow, we,ar rely     ,gud  at zhis proga m ing.. .. ..>! "")

}

// uppon runing this code, you will get this out put.........,

"wow, we,ar,,, rly god at this progm hal ing! .>>!1"

System.out.println("6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

                    6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!
")


/*
//will output*/
//
*/*/

// how do I type a lenny face? I tried but there arent the keys on my keyb oard. Please contat me at 737-247-4180 and tel me how to type a lenny face. Thnk you a lot! I ppreciate you. Arrowhead 4 lyfe! Soumil K rote this



6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!

6:04 PM	Thanks for the feedback!: We are glad to hear you are having a positive experience with Android Studio!
